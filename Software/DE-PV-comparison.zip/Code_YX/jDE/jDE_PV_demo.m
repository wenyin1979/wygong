function [recRMSE,bestP,optValue]=jDE_PV_demo(mType,Max_NFEs,NP)


    addpath('../CauchyFunction');
    addpath('../');

    %%��ʼ��
    [ UB,LB,Dim ] = Parameter(mType);
    G=0;%���õ���������ǰ����������
    index=mType;%���Ժ�������
    T=0.1;
    Fl=0.1;
    Fu=0.9;
    
  UB=(repmat((UB),NP,1));
    LB=repmat((LB),NP,1);
    P=(UB-LB).*rand(NP,Dim)+LB;%���������ʼ��Ⱥ����
    
%     if index==1
%         P=load('..\convergence-curve\InitPoPdata\model1pop.mat','Pinit');
%     elseif index==2
%         P=load('..\convergence-curve\InitPoPdata\model2pop.mat','Pinit');
%     elseif index==3
%         P=load('..\convergence-curve\InitPoPdata\model3pop.mat','Pinit');
%     elseif index==4
%         P=load('..\convergence-curve\InitPoPdata\model4pop.mat','Pinit');
%     elseif index==5
%         P=load('..\convergence-curve\InitPoPdata\model5pop.mat','Pinit');
%     end
%     P=double(P.Pinit);
    
    for i=1:NP
        fitnessP(i)=PV_TestFunction(index,P(i,:));%������Ⱥ������Ӧֵ
    end
    NFEs=NP;%��¼��Ӧ�Ⱥ������ô���
    [fitnessBestP,indexBestP]=min(fitnessP);
    bestP=P(indexBestP,:);
    recRMSE(1:NP)=fitnessP;

    F=0.5*ones(1,NP);
    CR=0.9*ones(1,NP);
    
    %%�����ѭ��
    while NFEs<Max_NFEs
        
        Fold=F;
        CRold=CR;
        
        for i=1:NP
            
            rand2=rand;
            if(rand2<T)
                rand1=rand;
                F(i)=Fl+rand1*Fu;
            end
            
            rand4=rand;
            if(rand4<T)
                rand3=rand;
                CR(i)=rand3;
            end
            
        end

        %%�������+�������
        for i=1:NP   
            
            %%�������
            
            %�ӵ�ǰ��ȺP�����ѡ��P1��P2��P3
            k0=randi([1,NP]);
            while(k0==i)
                k0=randi([1,NP]);   
            end
            P1=P(k0,:);
            k1=randi([1,NP]);
            while(k1==i||k1==k0)
                k1=randi([1,NP]);
            end
            P2=P(k1,:);
            k2=randi([1,NP]);
            while(k2==i||k2==k1||k2==k0)
                k2=randi([1,NP]);
            end
            P3=P(k2,:);

            V(i,:)=P1+F(i).*(P2-P3);   
       
            %%�߽紦��
            for j=1:Dim
              if (V(i,j)>UB(i,j))
                 V(i,j)=2*UB(i,j)-V(i,j);
              end
              if (V(i,j)<LB(i,j))
                 V(i,j)=2*LB(i,j)-V(i,j);
              end
           end
           
            %%�������
            jrand=randi([1,Dim]); 
            for j=1:Dim
                k3=rand;
                if(k3<=CR(i)||j==jrand)
                    U(i,j)=V(i,j);
                else
                    U(i,j)=P(i,j);
                end
            end
            fitnessU(i)=PV_TestFunction(index,U(i,:));
            NFEs=NFEs+1;
            
            %%ѡ�����
            if(fitnessU(i)<fitnessP(i))
                P(i,:)=U(i,:);
                fitnessP(i)=fitnessU(i);
 
                if(fitnessU(i)<fitnessBestP)
                   fitnessBestP=fitnessU(i);
                   bestP=U(i,:);
                end
            else
                F(i)=Fold(i);
                CR(i)=CRold(i);
            end
            
             recRMSE(NFEs)=fitnessP(i);
        end
        
       
        G=G+1;
        
    end
    
    optValue=fitnessBestP;
    

    
end
