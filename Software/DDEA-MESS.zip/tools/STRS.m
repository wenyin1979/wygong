function [Nap,fap,radius,flag] = STRS(Dim,ghx,ghf,FUN,L_bound, U_bound, radius)
%seedlocal Yseedlocal Range DIM STRFUN

    kernal='cubic';
    flag = 0;
    xmin = L_bound(1,1);
    xmax = U_bound(1,1);
    Range = repmat([xmin,xmax],Dim,1);
    D = Dim;
    kmax = 3;
    dlimit = 0.01;
    Seedlocal = ghx(1,:);
    YSeedlocal = ghf(1);

    lb=(Seedlocal-radius)';
    ub=(Seedlocal+radius)';
    for j=1:D
        if lb(j,1)<Range(j,1)
            lb(j,1)=Range(j,1);
        end
        if ub(j,1)>Range(j,2)
            ub(j,1)=Range(j,2);
        end
    end
    %%%%%%%%%%%%%%%%%%%%%
    DI=[];
    XI=[];
    YI=[];
    for j=1:length(ghx(:,1))
        d=norm(Seedlocal-ghx(j,:));
        if d>dlimit
            dj=fdistance(ghx(j,:),XI);
            if dj>dlimit
                XI=[XI;ghx(j,:)] ; 
                YI=[YI;ghf(j)] ; 
                DI=[DI;d];
            end
        end
    end
    ModelX=[];YModelX=[];
    len=5*D;%%%%%%%%%%%%%%%%%%%%%%%%
    if size(DI,1)<len
        ModelX=XI;
        YModelX=YI;
    else
        [DI,POS]=sort(DI);
        XI=XI(POS,:);
        YI=YI(POS,:);
        tt=0;
        for j=1:D
            tt=tt+(XI(len,j)<ub(j)&&XI(len,j)>lb(j));
        end
        if tt<D
            ModelX=XI(1:len,:);
            YModelX=YI(1:len,:);
        else
        for k=len:size(XI,1)
             tt=0;
                for j=1:D
                    tt=tt+(XI(k,j)<ub(j)&&XI(k,j)>lb(j));
                end
                if tt<D
                    break;
                end
        end
            ModelX=XI(1:k,:);
            YModelX=YI(1:k,:);
        end
    end
    ModelX=[ModelX;Seedlocal];
    YModelX=[YModelX;YSeedlocal]; 
    
    %lu = [min(ModelX); max(ModelX)];lbf = lu(1, :);ubf = lu(2, :);

    global coefC
    coefC=[];
    coefC=rbfcreate(ModelX',YModelX','RBFFunction', kernal);

try
    opts = optimset('Algorithm','sqp','Display', 'off','MaxIter',400,'MaxFunEvals',100*Dim);
    number = 9;
    Seedinitial=lhsdesign(number,Dim);
    for j=1:Dim
        Seedinitial(:,j)=Seedinitial(:,j)*(ub(j)-lb(j))+lb(j); 
    end
    Xnumber=[];Fnumber=[];
    for j=1:number   
        [x1,f1]=fmincon(@STRFUN,Seedinitial(j,:),[],[],[],[],lb,ub,[],opts);
        Xnumber=[Xnumber;x1];Fnumber=[Fnumber;f1];
    end
    [fap,id]=min(Fnumber);
    Nap=Xnumber(id,:);
    [Nap1,fap1]=fmincon(@STRFUN,Seedlocal,[],[],[],[],lb,ub,[],opts);
    if fap1<fap
        Nap=Nap1;
        fap=fap1;
    end

catch
    [Nap,fap]=YPSO(@STRFUN,[lb,ub],Dim);
end
    
    %%%% 更新信赖域
    if distance(Nap,ModelX)>10^-10
        fap=FUN(Nap);
        ro=(YSeedlocal-fap)/(STRFUN(Seedlocal)-STRFUN(Nap)-10^(-20)); %置信因子
        if fap<YSeedlocal
        Seedlocal=Nap;
        end
        if norm(Seedlocal-Nap)<radius
            es=1;
        end
        if norm(Seedlocal-Nap)>=radius
            es=2;
        end
        if ro<0.25
            radius=0.25*radius;
        end
        if ro>0.75
            radius=es*radius;
        end
        if ro>=0.25&&ro<=0.75
        end
        flag = 1;
    end
    
end
    

    