function [new_schedule, new_factory] = Genetic_operation_improvement(s1, s2, f1, f2)    %进行遗传操作产生新解
global N M F P G T O MU CR;

%可能出现不会进行交叉和变异的时候
if rand > 0.5
    new_schedule = s1;
    new_factory = f1;
else
    new_schedule = s2;
    new_factory = f2;
end

%%%采用POX交叉算子
if rand < CR
    %工件码交叉
    s1 = s1(1:N);
    s2 = s2(1:N);
    num = ceil(rand * (N - 1));     
    save1 = randperm(N, num);       %s1保留的工件
    save2 = [];                     %s2保留的工件
    t = 1:N;
    for i = 1:length(t)
        if ~ismember(t(i), save1)
            save2 = [save2, t(i)];
        end
    end

    reject1 = [];       %s1剔除的工件
    reject2 = [];       %s2剔除的工件
    for i = 1:length(s1)
        if ~ismember(s1(i), save1)
            reject1 = [reject1, s1(i)];
        end
    end
    for i = 1:length(s2)
        if ~ismember(s2(i), save2)
            reject2 = [reject2, s2(i)];
        end
    end

    %相互交叉
    s1_temp = s1;
    s2_temp = s2;
    count = 1;
    for i = 1:length(s1_temp)
        if ismember(s1_temp(i), reject1)
            s1_temp(i) = save2(count);
            count = count + 1;
        end
    end
    count = 1;
    for i = 1:length(s2_temp)
        if ismember(s2_temp(i), reject2)
            s2_temp(i) = save1(count);
            count = count + 1;
        end
    end


%     %工厂码交叉
%     f1 = f1(1:N);
%     f2 = f2(1:N);
%     save_index1 = [];       %s1保存工厂的索引值
%     save_index2 = [];       %s2保存工厂的索引值
%     reject_index1 = [];     %s1剔除工厂的索引值
%     reject_index2 = [];     %s2剔除工厂的索引值
%     for i = 1:length(save1)
%         index = find(s1 == save1(i));
%         save_index1 = [save_index1, index];
%     end
%     for i = 1:length(save2)
%         index = find(s2 == save2(i));
%         save_index2 = [save_index2, index];
%     end
%     for i = 1:length(reject1)
%         index = find(s1 == reject1(i));
%         reject_index1 = [reject_index1, index];
%     end
%     for i = 1:length(reject2)
%         index = find(s2 == reject2(i));
%         reject_index2 = [reject_index2, index];
%     end
    f1_temp = f1;
    f2_temp = f2;
%     temp = f1_temp;
%     f1_temp(reject_index1) = f2_temp(save_index2);
%     f2_temp(reject_index2) = temp(save_index1);

    %随机选取一个保留
    judge = round(rand);
    if judge == 1
        new_schedule = Expand(s1_temp);
        new_factory = Expand(f1_temp);
    else
        new_schedule = Expand(s2_temp);
        new_factory = Expand(f2_temp);
    end
end

    

% %%%产生1~N的随机0-1数列，随机打乱数列中为1的位置的工件码、工厂码
% s1_temp = s1;
% s2_temp = s2;
% f1_temp = f1;
% f2_temp = f2;
% 
% array = round(rand(1, N));
% disturb_index1 = find(array == 1);       %需要交换的位置
% idx = randperm(length(disturb_index1));      %随机打乱
% disturb_index2 = disturb_index1(idx);     %打乱后需要交换的位置
% 
% %随机选取一个保留
% judge = round(rand);
% if judge == 1
%     s1_temp(disturb_index1) = s1_temp(disturb_index2);
%     f1_temp(disturb_index1) = f1_temp(disturb_index2);
%     new_schedule = Expand(s1_temp);
%     new_factory = Expand(f1_temp);
% else
%     s2_temp(disturb_index1) = s2_temp(disturb_index2);
%     f2_temp(disturb_index1) = f2_temp(disturb_index2);
%     new_schedule = Expand(s2_temp);
%     new_factory = Expand(f2_temp);
% end



%%%产生1~N的随机0-1数列，随机打乱数列中为1的位置的工件码、工厂码
s_temp = new_schedule(1:N);
f_temp = new_factory(1:N);

array = round(rand(1, N));
disturb_index1 = find(array == 1);       %需要交换的位置
idx = randperm(length(disturb_index1));      %随机打乱
disturb_index2 = disturb_index1(idx);     %打乱后需要交换的位置

s_temp(disturb_index1) = s_temp(disturb_index2);
f_temp(disturb_index1) = f_temp(disturb_index2);
new_schedule = Expand(s_temp);
new_factory = Expand(f_temp);



%%%变异操作，随机选取一个工厂码进行变异
if rand < MU
    judge = tabulate(new_factory(1:N));     %确保每个工厂至少有两个工件加工
    if all(judge(:, 2) > 2)
        pos = ceil(rand * N);
        choice = ceil(rand * F);
        while choice == new_factory(pos)
            choice = ceil(rand * F);
        end
        for i = 1:M
            new_factory(pos + (i - 1) * N) = choice;
        end
    end
end


end