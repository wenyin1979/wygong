function [critical_factory, makespan] = Calculate_makespan(schedule, factory, processing_time)
%计算makespan，寻找关键工厂
global N M F P G T O MU;

len = size(schedule, 1);
for i = 1:len
    makespan = 0;       %最大完工时间
    critical_factory = 1;        %关键工厂
    for j = 1:F
        index = find(factory(i, :) == j);      %寻找在工厂j加工的工件
        schedule_temp = schedule(i, index);    %存储在工厂j加工的工件
        
        start_time = zeros((size(schedule_temp, 2) / M), M);       %存储在工厂j加工的工件的开始时间
        end_time = zeros((size(schedule_temp, 2) / M), M);         %存储在工厂j加工的工件的结束时间
        machine_time = zeros(1, M);     %存储在工厂j的机器完工时间
        job = schedule_temp(1:(size(schedule_temp, 2) / M));       %存储在工厂j加工的工件有哪些
        
        s1 = schedule_temp;     %s1存储种群个体
        s2 = [];    %s2存储每个工件是第几个工序
        order = 1;
        for k = 1:size(s1, 2)
            s2(k) = order;
            if mod(k, size(job, 2)) == 0
                order = order + 1;
            end
        end
            
        for k = 1:size(s1, 2)
            if s2(k) == 1
                idx = find(job == s1(k));
                start_time(idx, 1) = machine_time(1);
                end_time(idx, 1) = start_time(idx, 1) + processing_time(s1(k), (j - 1) * M + 1);
                machine_time(1) = end_time(idx, 1);
            else
                idx = find(job == s1(k));
                start_time(idx, s2(k)) = max(machine_time(s2(k)), end_time(idx, s2(k) - 1));
                end_time(idx, s2(k)) = start_time(idx, s2(k)) + processing_time(s1(k), (j - 1) * M + s2(k));
                machine_time(s2(k)) = end_time(idx, s2(k));
            end
        end
        
        %计算最大完工时间以及关键工厂号
        current_makespan = max(machine_time);
        if current_makespan >= makespan
            critical_factory = j;
            makespan = current_makespan;
        end

        
    end
    
    
end


end