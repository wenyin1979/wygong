function [] = KOMEAD_built_in(Energy_consumption_power, namelist, file_index)
global N M F P G T O MU CR;

%提取出N，M，F
parameter = regexp(namelist(file_index), '\d*', 'match');
    
N = str2num(parameter{1});     %工件数，使用不同的数据集工件数不同
M = str2num(parameter{2});      %机器数，使用不同的数据集机器数不同
F = str2num(parameter{3});      %工厂数，使用不同的数据集工厂数不同
    
P = 100;    %种群大小
G = 200;    %迭代次数
    
T = 15;     %每一个权重向量的邻居个数
O = 2;     %优化目标个数
CR = 0.7;   	%交叉概率
MU = 0.1;   	%变异概率
    
%创建文件夹
dirname = ['KMOEAD\', num2str(N), '_', num2str(M), '_', num2str(F)];
mkdir(dirname);
    
processing_time = xlsread(['dataset\', char(namelist(file_index))]);      %读取工件的加工时间
    
for run = 1:20       %独立运行run次
    fprintf('**********N=%d,M=%d,F=%d: 第%d次独立运行**********\n', N, M, F, run);
    PF = [];    %存储非支配解
    %[schedule, factory, reference_vector] = Initial_randomn(run);      %初始化工件码、工厂码、参考向量                                                                                                                                                                                             
    [schedule, factory, reference_vector] = Initial_NEH(processing_time, Energy_consumption_power, run);      %初始化工件码、工厂码、参考向量                                                                                                                                                                                             

    %寻找最近的T个邻居的索引值
    neighbor_index = Get_neighbor(reference_vector);        

    %计算目标值
    %objective_value = Calculate_objective_value(schedule, factory, processing_time, Energy_consumption_power);        %计算目标值(第一个值为最大完工时间，第二个值为总能量消耗)
    objective_value = Calculate_objective_value_ES(schedule, factory, processing_time, Energy_consumption_power);        %计算目标值(第一个值为最大完工时间，第二个值为总能量消耗)

    %初始化参考点
    for i = 1:2
        reference_point(i) = min(objective_value(:, i));        
    end
        
    %计算切比雪夫值
    tchebycheff = Calculate_Tchebycheff(objective_value, reference_vector, reference_point);    
    fitness = [objective_value, tchebycheff];       %前两个值为最大完工时间和总能量消耗，最后一个值为Tchebycheff值

    [PF, PF_index] = Nondominated_solution(objective_value);
    PF_schedule = schedule(PF_index, :);
    PF_factory = factory(PF_index, :);
    
    %迭代循环
    for i = 1:G
        gen = i;
        fprintf('第%d次迭代\n', i);
        for j = 1:P
            %遗传操作产生新解
%             rng(run);
            index = randperm(T);
            index1 = neighbor_index(j, index(1));
            index2 = neighbor_index(j, index(2));
                
            %遗传操作
            %[new_schedule, new_factory] = Genetic_operation(schedule(index1, :), schedule(index2, :), factory(index1, :), factory(index2, :));
            [new_schedule, new_factory] = Genetic_operation_improvement(schedule(index1, :), schedule(index2, :), factory(index1, :), factory(index2, :));

            %%%局部搜索
            [critical_factory, ~] = Calculate_makespan(new_schedule, new_factory, processing_time);
            [new_schedule, new_factory] = Local_search(critical_factory, new_schedule, new_factory, file_index);

            
            %求目标值
            %new_objective_value = Calculate_objective_value(new_schedule, new_factory, processing_time, Energy_consumption_power);
            new_objective_value = Calculate_objective_value_ES(new_schedule, new_factory, processing_time, Energy_consumption_power);

            %如果新生成的解比原来解好就更新邻域
            if (Nondominated_judge(objective_value(j, :), new_objective_value) == -1)
                schedule(j, :) = new_schedule;
                factory(j, :) = new_factory;
                objective_value(j, :) = new_objective_value;
                new_tchebycheff = Calculate_Tchebycheff(new_objective_value, reference_vector, reference_point);
                fitness(j, :) = [new_objective_value, new_tchebycheff];
            elseif (Nondominated_judge(objective_value(j, :), new_objective_value) == 0)
%                 PF = [PF; new_objective_value];
                [PF, PF_schedule, PF_factory] = Update_PF(PF, new_objective_value, new_schedule, new_factory, PF_schedule, PF_factory);
            end
            
            %更新参考点
            for i = 1:2
                reference_point(i) = min(new_objective_value(i), reference_point(i));        %更新参考点
            end

            %更新邻域解
            [schedule, factory, objective_value, fitness] = Update_neighbor_solution(schedule, factory, objective_value, fitness, neighbor_index(j, :), reference_vector(j, :), reference_point, new_schedule, new_factory, new_objective_value);
            
            %更新非支配解
            [PF, PF_schedule, PF_factory] = Update_PF(PF, new_objective_value, new_schedule, new_factory, PF_schedule, PF_factory);
        end
        [PF, PF_schedule, PF_factory] = Collaborative_local_search(PF, PF_schedule, PF_factory, processing_time, Energy_consumption_power);  
    end
        
%     %得到非支配解
%     PF = Nondominated_solution(objective_value);
%     solutions = [objective_value, zeros(size(objective_value, 1), 1)];
%     for i = 1:size(PF, 1)
%         for j = 1:size(objective_value, 1)
%             if PF(i, :) == objective_value(j, :)
%                 solutions(j, 3) = 1;
%             end
%         end
%     end
        
    %存储数据
    final_PF = unique(PF, 'rows');
    filename = ['KMOEAD\', num2str(N), '_', num2str(M), '_', num2str(F), '\', num2str(run), '.xlsx'];
    xlswrite(filename, final_PF);
        
end


end