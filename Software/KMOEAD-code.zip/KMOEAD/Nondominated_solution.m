function [PF, index] = Nondominated_solution(objective_value)    %找出非支配解
global N M F P G T O MU;
dominated = zeros(1, P);
for i = 1:P
    for j = 1:P
        if all(objective_value(i, :) >= objective_value(j, :)) && any(objective_value(i, :) > objective_value(j, :))
            dominated(i) = 1;
            break;
        end
    end
end    

index = find(dominated == 0);
PF = objective_value(index, :);

end