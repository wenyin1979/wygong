function [new_schedule, new_factory] = Local_search(critical_factory, new_schedule, new_factory, file_index)
%局部搜索
global N M F P G T O MU;


%%%LS1：从关键工厂中提取随机提取一个工件，将其插入该关键工厂中的一个随机位置
if file_index <= 60
    if mod(file_index, 2) == 1
        schedule_temp = new_schedule(1:N);
        factory_temp = new_factory(1:N);
        index = find(factory_temp == critical_factory);
        schedule_segment = schedule_temp(index);
        factory_segment = factory_temp(index);

        %如果插入位置与待插入工件位置相同，则重新选择
        ext_pos = ceil(rand * length(schedule_segment));
        ins_pos = ceil(rand * length(schedule_segment));
        while ins_pos == ext_pos
            ins_pos = ceil(rand * length(schedule_segment));
        end

       %插入工件
       [schedule_segment, factory_segment] = Insert_operator(schedule_segment, factory_segment, ext_pos, ins_pos);
       schedule_temp(index) = schedule_segment;
       factory_temp(index) = factory_segment;
       new_schedule = Expand(schedule_temp);
       new_factory = Expand(factory_temp);
    end
end





%%%LS2：从关键工厂中随机提取一个工件，将其随机插入到非关键工厂中的一个随机位置
if file_index > 60
    if mod(file_index, 2) == 1
        schedule_temp = new_schedule(1:N);
        factory_temp = new_factory(1:N);

        %随机提取关键工厂中的工件
        index = find(factory_temp == critical_factory);

        %确保关键工厂中必须至少有两个工件加工
        if length(index) > 2
            idx = ceil(rand * length(index));
            ext_job = schedule_temp(index(idx));

            %将其插入随机的非关键工厂
            noncritical_factory = ceil(rand * F);
            while noncritical_factory == critical_factory
                noncritical_factory = ceil(rand * F);
            end
            factory_temp(index(idx)) = noncritical_factory;

            %提取需要进行插入操作的工件码段和工厂码段
            index = find(factory_temp == noncritical_factory);
            schedule_segment = schedule_temp(index);
            factory_segment = factory_temp(index);

            %如果插入位置与待插入工件位置相同，则重新选择
            ext_pos = find(schedule_segment == ext_job);
            ins_pos = ceil(rand * length(schedule_segment));

            if ins_pos == ext_pos
                %经过变异操作后可能存在非关键工厂上只有0个或1个工件的情况
            else
                %插入工件
                [schedule_segment, factory_segment] = Insert_operator(schedule_segment, factory_segment, ext_pos, ins_pos);
            end

            schedule_temp(index) = schedule_segment;
            factory_temp(index) = factory_segment;
            new_schedule = Expand(schedule_temp);
            new_factory = Expand(factory_temp);
        end
    end
end





%%%LS3：随机互换关键工厂中的两个工件
if file_index <= 60
    if mod(file_index, 2) == 0
        schedule_temp = new_schedule(1:N);
        factory_temp = new_factory(1:N);
        index = find(factory_temp == critical_factory);

        %随机选取关键工厂中的两个工件
        idx1 = ceil(rand * length(index));
        idx2 = ceil(rand * length(index));
        while idx1 == idx2
            idx2 = ceil(rand * length(index));
        end

        %互换两个工件
        temp1 = schedule_temp(index(idx1));
        %temp2 = factory_temp(index(idx1));
        schedule_temp(index(idx1)) = schedule_temp(index(idx2));
        %factory_temp(index(idx1)) = factory_temp(index(idx2));
        schedule_temp(index(idx2)) = temp1;
        %factory_temp(index(idx2)) = temp2;
        new_schedule = Expand(schedule_temp);
        new_factory = Expand(factory_temp);
    end
end





%%%LS4：随机互换关键工厂和非关键工厂的两个工件
if file_index > 60
    if mod(file_index, 2) == 0
        schedule_temp = new_schedule(1:N);
        factory_temp = new_factory(1:N);

        critical_index = find(factory_temp == critical_factory);

        %随机选取一个非关键工厂,但是该非关键工厂必须有工件在加工
        noncritical_factory = ceil(rand * F);
        while noncritical_factory == critical_factory | length(find(factory_temp == noncritical_factory)) == 0
            noncritical_factory = ceil(rand * F);
        end
        noncritical_index = find(factory_temp == noncritical_factory);

        %随机选取一个关键工厂工件和非关键工厂工件
        critical_idx = ceil(rand * length(critical_index));
        noncritical_idx = ceil(rand * length(noncritical_index));

        %互换两个工件(待考察！！！！！！！)
        temp1 = schedule_temp(critical_index(critical_idx));
        %temp2 = factory_temp(critical_index(critical_idx));
        schedule_temp(critical_index(critical_idx)) = schedule_temp(noncritical_index(noncritical_idx));
        %factory_temp(critical_index(critical_idx)) = factory_temp(noncritical_index(noncritical_idx));
        schedule_temp(noncritical_index(noncritical_idx)) = temp1;
        %factory_temp(noncritical_index(noncritical_idx)) = temp2;
        new_schedule = Expand(schedule_temp);
        new_factory = Expand(factory_temp);
    end
end





end