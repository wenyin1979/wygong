function value = GD(pareto, true_pareto, max_and_min)       %计算GD值，默认都是按照x的值排好序的

if size(pareto, 1) == 1 && size(true_pareto, 1) == 1 && isequal(pareto, true_pareto)
    value = 0;
else
    %归一化
    max_value_x = max_and_min(1, 1);
    min_value_x = max_and_min(2, 1);
    max_value_y = max_and_min(1, 2);
    min_value_y = max_and_min(2, 2);
    for i = 1:size(pareto, 1)
        pareto(i, 1) = (pareto(i, 1) - min_value_x) / (max_value_x - min_value_x);
        pareto(i, 2) = (pareto(i, 2) - min_value_y) / (max_value_y - min_value_y);
    end
    for i = 1:size(true_pareto, 1)
        true_pareto(i, 1) = (true_pareto(i, 1) - min_value_x) / (max_value_x - min_value_x);
        true_pareto(i, 2) = (true_pareto(i, 2) - min_value_y) / (max_value_y - min_value_y);
    end


    distance = 0;
    for i = 1:size(pareto, 1)
        distance_min = inf;
        for j = 1:size(true_pareto, 1)
            dis = (pareto(i, 1) - true_pareto(j, 1))^2 + (pareto(i, 2) - true_pareto(j, 2))^2;
            if dis < distance_min
                distance_min = dis;
            end
        end
        distance = distance + distance_min;
    end

    value = sqrt(distance) / size(pareto, 1);
end

end