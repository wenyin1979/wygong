function value = Spread(pareto, true_pareto, max_and_min)    %计算Spread值，默认都是按照x的值排好序的

%归一化
max_value_x = max_and_min(1, 1);
min_value_x = max_and_min(2, 1);
max_value_y = max_and_min(1, 2);
min_value_y = max_and_min(2, 2);
for i = 1:size(pareto, 1)
    pareto(i, 1) = (pareto(i, 1) - min_value_x) / (max_value_x - min_value_x);
    pareto(i, 2) = (pareto(i, 2) - min_value_y) / (max_value_y - min_value_y);
end
for i = 1:size(true_pareto, 1)
    true_pareto(i, 1) = (true_pareto(i, 1) - min_value_x) / (max_value_x - min_value_x);
    true_pareto(i, 2) = (true_pareto(i, 2) - min_value_y) / (max_value_y - min_value_y);
end


%计算Spread值
if size(pareto, 1) == 1
    value = 1;
else
    pareto = sortrows(pareto, 1);
    true_pareto = sortrows(true_pareto, 1);
    df = sqrt((pareto(1, 1) - true_pareto(1, 1))^2 + (pareto(1, 2) - true_pareto(1, 2))^2);
    dl = sqrt((pareto(size(pareto, 1), 1) - true_pareto(size(true_pareto, 1), 1))^2 + (pareto(size(pareto, 1), 2) - true_pareto(size(true_pareto, 1), 2))^2);
    distance_array = [];
    for i = 1:(size(pareto, 1) - 1)
        dis = sqrt((pareto(i, 1) - pareto(i + 1, 1))^2 + (pareto(i, 2) - pareto(i + 1, 2))^2);
        distance_array = [distance_array, dis];
    end
    distance_mean = mean(distance_array);
    distance_sum = 0;
    for i = 1:size(distance_array, 1)
        distance_sum = distance_sum + abs(distance_array(i) - distance_mean);
    end
    value = (df + dl + distance_sum) / (df + dl + size(distance_array, 1) * distance_mean);
end

end