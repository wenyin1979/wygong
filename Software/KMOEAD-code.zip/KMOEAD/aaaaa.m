[true_pareto, max_and_min] = Pareto(solutions);

GD_value = zeros(length(true_pareto), 5);
for i = 1:length(true_pareto)
    for j = 1:5
        GD_temp = 0;
        for k = 1:20
            GD_temp = GD_temp + GD(solutions{j}{i}{k}, true_pareto{i}, max_and_min{i});
        end
        GD_value(i, j) = GD_temp / 20;
    end
    
end

HV_value = zeros(length(true_pareto), 5);
for i = 1:length(true_pareto)
    for j = 1:5
        HV_temp = 0;
        for k = 1:20
            HV_temp = HV_temp + HV(solutions{j}{i}{k}, max_and_min{i});
        end
        HV_value(i, j) = HV_temp / 20;
    end
    
end

Spread_value = zeros(length(true_pareto), 5);
for i = 1:length(true_pareto)
    for j = 1:5
        Spread_temp = 0;
        for k = 1:20
            Spread_temp = Spread_temp + Spread(solutions{j}{i}{k}, true_pareto{i}, max_and_min{i});
        end
        Spread_value(i, j) = Spread_temp / 20;
    end
    
end

IGD_value = zeros(length(true_pareto), 5);
for i = 1:length(true_pareto)
    for j = 1:5
        IGD_temp = 0;
        for k = 1:20
            IGD_temp = IGD_temp + IGD(solutions{j}{i}{k}, true_pareto{i}, max_and_min{i});
        end
        IGD_value(i, j) = IGD_temp / 20;
    end
    
end
