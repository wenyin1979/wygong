function result = Expand(t)     %扩展编码
global N M F P G T O MU;

result = [];
for i = 1:M
    result = [result, t];
end

end