function objective_value = Calculate_objective_value_ES(schedule, factory, processing_time, Energy_consumption_power)    %计算makespan和total energy consumption
global N M F P G T O MU;

objective_value = [];
len = size(schedule, 1);
for i = 1:len
    makespan = 0;       %最大完工时间
    total_energy_consumption = 0;       %总的能量消耗
    start_end = {};     %存储每个工厂的每个工件加工的开始、结束时间
    for j = 1:F
        idle_time = 0;      %空闲时间
        workload = 0;       %机器负载
        index = find(factory(i, :) == j);      %寻找在工厂j加工的工件
        schedule_temp = schedule(i, index);    %存储在工厂j加工的工件
        
        start_time = zeros((size(schedule_temp, 2) / M), M);       %存储在工厂j加工的工件的开始时间
        end_time = zeros((size(schedule_temp, 2) / M), M);         %存储在工厂j加工的工件的结束时间
        machine_time = zeros(1, M);     %存储在工厂j的机器完工时间
        job = schedule_temp(1:(size(schedule_temp, 2) / M));       %存储在工厂j加工的工件有哪些
        
        s1 = schedule_temp;     %s1存储种群个体
        s2 = [];    %s2存储每个工件是第几个工序
        order = 1;
        for k = 1:size(s1, 2)
            s2(k) = order;
            if mod(k, size(job, 2)) == 0
                order = order + 1;
            end
        end
            
        for k = 1:size(s1, 2)
            if s2(k) == 1
                idx = find(job == s1(k));
                start_time(idx, 1) = machine_time(1);
                end_time(idx, 1) = start_time(idx, 1) + processing_time(s1(k), (j - 1) * M + 1);
                machine_time(1) = end_time(idx, 1);
                workload = workload + processing_time(s1(k), (j - 1) * M + 1);
            else
                idx = find(job == s1(k));
                start_time(idx, s2(k)) = max(machine_time(s2(k)), end_time(idx, s2(k) - 1));
                end_time(idx, s2(k)) = start_time(idx, s2(k)) + processing_time(s1(k), (j - 1) * M + s2(k));
                machine_time(s2(k)) = end_time(idx, s2(k));
                workload = workload + processing_time(s1(k), (j - 1) * M + s2(k));
            end
        end
        
        
        
        %%%节能策略
        [start_time, end_time] = Energy_saving(start_time, end_time);
        
        
        %计算最大完工时间以及每个工厂的总能量消耗
        makespan = max(makespan, max(machine_time));
        for k = 1:M
            for l = 2:size(start_time, 1)
                idle_time = idle_time + (start_time(l, k) - end_time(l - 1, k));
            end
        end
        total_energy_consumption = total_energy_consumption + M * Energy_consumption_power(j, 1) + workload * Energy_consumption_power(j, 2) + idle_time * Energy_consumption_power(j, 3);
       
        %将工件的在各个机器上的开始加工时间和结束加工时间存储起来
        start_end{j, 1} = start_time;
        start_end{j, 2} = end_time;
        
    end
    
    %将最大完工时间和总能量消耗存储起来
    array(1, 1) = makespan;
    array(1, 2) = total_energy_consumption;
    objective_value = [objective_value; array];
    
end
    
end