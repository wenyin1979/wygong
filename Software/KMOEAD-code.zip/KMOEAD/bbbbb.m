true_pareto = Pareto(solutions);

GD_value = zeros(72, 5);
for i = 1:length(solutions)
    for j = 1:length(solutions{i})
        array = [];
        for k = 1:length(solutions{i}{j})
            array = [array; solutions{i}{j}{k}];
        end
        array = unique(array(:, 1:2), 'rows');
        len = size(array, 1);
        dominated = zeros(1, len);
        for k = 1:len
            for l = 1:len
                if all(array(k, :) >= array(l, :)) && any(array(k, :) > array(l, :))
                    dominated(k) = 1;
                    break;
                end
            end
        end 
        
        index = find(dominated == 0);
        true_pareto = array(index, :);
        
        GD_temp = 0;
        for k = 1:length(solutions{i}{j})
            GD_temp = GD_temp + GD(solutions{i}{j}{k}, true_pareto);
        end
        
        GD_value(j, i) = GD_temp / 20;
    end
    
end