clc;
clear;

dirlist = ["KMOEAD", "KMOEAD1", "KMOEAD2", "KMOEAD3", "KMOEAD4"];

solutions = {};
for i = 1:length(dirlist)
    dirname = char(dirlist(i));
%     filename = dir(dirname);
    
    filelist = ["8_2_2"; "8_2_3"; "8_2_4"; "8_3_2"; "8_3_3"; "8_3_4";
                "8_4_2"; "8_4_3"; "8_4_4"; "8_5_2"; "8_5_3"; "8_5_4";
                "12_2_2"; "12_2_3"; "12_2_4"; "12_3_2"; "12_3_3"; "12_3_4";
                "12_4_2"; "12_4_3"; "12_4_4"; "12_5_2"; "12_5_3"; "12_5_4";
                "16_2_2"; "16_2_3"; "16_2_4"; "16_3_2"; "16_3_3"; "16_3_4";
                "16_4_2"; "16_4_3"; "16_4_4"; "16_5_2"; "16_5_3"; "16_5_4";
                "20_2_2"; "20_2_3"; "20_2_4"; "20_3_2"; "20_3_3"; "20_3_4";
                "20_4_2"; "20_4_3"; "20_4_4"; "20_5_2"; "20_5_3"; "20_5_4";
                "24_2_2"; "24_2_3"; "24_2_4"; "24_3_2"; "24_3_3"; "24_3_4";
                "24_4_2"; "24_4_3"; "24_4_4"; "24_5_2"; "24_5_3"; "24_5_4";
                "100_5_4"; "100_5_6"; "100_5_8"; "100_10_4"; "100_10_6"; "100_10_8";
                "200_5_4"; "200_5_6"; "200_5_8"; "200_10_4"; "200_10_6"; "200_10_8"];
    
    temp_solutions = {};
    for j = 1:72
         excellist = dir([dirname, '\', char(filelist(j)), '\*.xlsx']);
         index = 1;
         len = length(excellist);
         temp = {};
         fprintf('******%d Load Data: %s******\n', j, [dirname, '\', char(filelist(j))]);
         while (index <= len)
             data = xlsread([dirname, '\', char(filelist(j)), '\', excellist(index).name]);
             temp{end + 1} = unique(data(:, 1:2), 'rows');
             index = index + 1;
         end
         temp_solutions{end + 1} = temp;
    end
    solutions{end + 1} = temp_solutions;
end
    