clc;
clear;

global N M F P G T O MU CR;

P_array = [40, 60, 80, 100];
T_array = [5, 10, 15, 20];
CR_array = [0.7, 0.8, 0.9, 1.0];
MU_array = [0.1, 0.2, 0.3, 0.4];

%设计正交表
L16 = sortrows(rowexch(4, 16, 'l', 'cat', 1:4, 'levels', 4*ones([1, 4]), 'tries', 100));
xlswrite('Orthogonal_table.xlsx', L16);

parfor row = 1:16
   
    Taguchi_Method_Simplify_built_in(row, L16, P_array, T_array, CR_array, MU_array);

    
end