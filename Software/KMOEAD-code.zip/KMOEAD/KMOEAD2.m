clc;
clear;

global N M F P G T O MU CR;

%机器的能量消耗：第一个为机器的启动关闭能量消耗量，第二个为机器工作时的能量消耗功率，第三个为机器空闲时的能量消耗功率
Energy_consumption_power = [35, 3, 1.125;
                            40, 2.875, 1.25;
                            45, 2.75, 1.375;
                            50, 2.625, 1.5;
                            55, 2.5, 1.625;
                            60, 2.375, 1.75;
                            65, 2.25, 1.875;
                            70, 2.125, 2]; 
                        
%所有的xlsx文件
namelist = dir('dataset\*.xlsx');   
            
%%%遍历所有xlsx文件
file_index = 1;
len = length(namelist);

parfor file_index = 1:len
    
    KOMEAD2_built_in(Energy_consumption_power, namelist, file_index);
    
end




