function [PF, PF_schedule, PF_factory] = Update_PF(PF, new_objective_value, new_schedule, new_factory, PF_schedule, PF_factory)
global N M F P G T O MU CR;

dominated = zeros(1, length(PF));
for i = 1:size(PF, 1)
    if all(PF(i, :) >= new_objective_value(1, :)) && any(PF(i, :) > new_objective_value(1, :))
        dominated(i) = 1;
    end
end
index = find(dominated == 1);
PF(index, :) = [];
PF_schedule(index, :) = [];
PF_factory(index, :) = [];



if isempty(PF)
    PF = [PF; new_objective_value];
    PF_schedule = new_schedule;
    PF_factory = new_factory;
else
    dominated = 0;
    for i = 1:size(PF, 1)
        if all(PF(i, :) <= new_objective_value(1, :)) && any(PF(i, :) < new_objective_value(1, :))
            dominated = 1;
            break
        end
    end
    if dominated == 0
        PF = [PF; new_objective_value];
        PF_schedule = [PF_schedule; new_schedule];
        PF_factory = [PF_factory; new_factory];
    end
end



end


