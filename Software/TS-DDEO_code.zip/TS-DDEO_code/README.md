# TS-DDEA_Code

Code for the implementation of Two-stage Data-driven Evolutionary Optimization (TS-DDEO)
Huixiang Zhen, Wenyin Gong, Ling Wang, Fei Ming, and Zuowen Liao. "Two-stage Data-driven Evolutionary Optimization for High-dimensional Expensive Problems", 
IEEE Transactions on Cybernetics, accepted, 2021.

This paper and this code should be referenced whenever they are used to generate results for the user's own research.
This matlab code was written by Huixiang Zhen: School of Computer Science, China University of Geoscience. 
Please refer with all questions, comments, bug reports, etc. to zhenhuixiang@cug.edu.cn or 765628993@qq.com.