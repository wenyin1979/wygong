# MS-DDEO Code

% This code is part of the program that produces the results in the following paper:
Huixiang Zhen, Wenyin Gong, and Ling Wang. "Offline data-driven evolutionary optimization based on model selection", Swarm and Evolutionary Computation, accepted, 2022.

This matlab code was written by Huixiang Zhen, School of Computer Science, China University of Geoscience. 
Please refer with all questions, comments, bug reports, etc. to zhenhuixiang@cug.edu.cn or 765628993@qq.com.