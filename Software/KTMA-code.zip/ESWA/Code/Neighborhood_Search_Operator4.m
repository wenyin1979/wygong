function [OS_offspring4, MS_offspring4, SS_offspring4] = Neighborhood_Search_Operator4(p_chrom, m_chrom, s_chrom, criticalPath, s2, processingTime)
%%%VNS4：随机选取非关键路径上的一个工序，将其加工机器的机器速度降低一档

global H SH;

OS_offspring4 = p_chrom;
MS_offspring4 = m_chrom;
SS_offspring4 = s_chrom;

noncriticalPath = 1:SH;
noncriticalPath(criticalPath) = [];     %%非关键路径
idx = randperm(length(noncriticalPath), 1);
index = noncriticalPath(idx);      %选取工序索引
job = OS_offspring4(index);     %选取工件
op = s2(index);     %选取工序

if SS_offspring4(sum(H(1:job - 1)) + op) > 1
    SS_offspring4(sum(H(1:job - 1)) + op) = SS_offspring4(sum(H(1:job - 1)) + op) - 1;
end

end