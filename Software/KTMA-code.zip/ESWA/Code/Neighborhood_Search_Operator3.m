function [OS_offspring3, MS_offspring3, SS_offspring3] = Neighborhood_Search_Operator3(p_chrom, m_chrom, s_chrom, criticalPath, s2, processingTime)
%%%VNS3：随机选取关键路径上的一个工序，将其随机插入到不同的备选机器上

global H;

OS_offspring3 = p_chrom;
MS_offspring3 = m_chrom;
SS_offspring3 = s_chrom;

idx = randperm(length(criticalPath), 1);
index = criticalPath(idx);      %选取工序索引
job = OS_offspring3(index);     %选取工件
op = s2(index);     %选取工序

availableMachineSet = find(processingTime{job}(op, :) > 0);     %备选机器集
machineNo = availableMachineSet(randperm(length(availableMachineSet), 1));      %选出的备选机器
MS_offspring3(sum(H(1:job - 1)) + op) = machineNo;

end