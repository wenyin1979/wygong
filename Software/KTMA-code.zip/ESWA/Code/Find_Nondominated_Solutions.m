function solutions = Find_Nondominated_Solutions(solutions)

solutions = unique(solutions, 'row');
len = size(solutions, 1);
nondominated = zeros(1, len);
for i = 1:len
    for j = 1:len
        if all(solutions(j, :) <= solutions(i, :)) && any(solutions(j, :) < solutions(i, :))
            nondominated(i) = 1;
        end
    end
end
index = find(nondominated == 0);
solutions = solutions(index, :);

end