function [OS_offspring1, MS_offspring1, SS_offspring1] = Neighborhood_Search_Operator1(p_chrom, m_chrom, s_chrom, criticalPath, criticalPathBlock, s2, processingTime)
%%%VNS1：交换关键路径块上的前两个工序，如果不存在关键路径块则随机交换关键路径上的两个工件

global H M;

OS_offspring1 = p_chrom;
MS_offspring1 = m_chrom;
SS_offspring1 = s_chrom;
if isempty(criticalPathBlock)
    %%%如果不存在关键路径块则随机交换关键路径上的属于同一机器上的两个工件，否则保持不变
    machineStatus = cell(1, M);     %存储每台机器上有哪些工件加工
    for i = 1:length(criticalPath)
        job = OS_offspring1(criticalPath(i));   %加工工件
        op = s2(criticalPath(i));   %加工工序
        machine = MS_offspring1(sum(H(1:job - 1)) + op);    %加工机器
        machineStatus{machine} = [machineStatus{machine}, criticalPath(i)];
    end
    
    availableMachine = [];
    for i = 1:M
        if length(machineStatus{i}) > 1
            availableMachine = [availableMachine, i];       %存储可选机器
        end
    end
    
    if ~isempty(availableMachine) 
        machineSelection = availableMachine(randperm(length(availableMachine), 1));   %选出机器
        subCriticalPath = machineStatus{machineSelection};
        idx = randperm(length(subCriticalPath), 2);
        index1 = subCriticalPath(idx(1));    %交换工件的索引号
        index2 = subCriticalPath(idx(2));    %交换工件的索引号
        job1 = OS_offspring1(index1);   %工件1
        job2 = OS_offspring1(index2);   %工件2

        %%%交换工序码
        OS_offspring1(index1) = job2;
        OS_offspring1(index2) = job1;

        %%%交换机器码
        temp = MS_offspring1(sum(H(1:job1 - 1)) + s2(index1));
        MS_offspring1(sum(H(1:job1 - 1)) + s2(index1)) = MS_offspring1(sum(H(1:job2 - 1)) + s2(index2));
        MS_offspring1(sum(H(1:job2 - 1)) + s2(index2)) = temp;

        %%%交换机器速度码
        temp = SS_offspring1(sum(H(1:job1 - 1)) + s2(index1));
        SS_offspring1(sum(H(1:job1 - 1)) + s2(index1)) = SS_offspring1(sum(H(1:job2 - 1)) + s2(index2));
        SS_offspring1(sum(H(1:job2 - 1)) + s2(index2)) = temp;
        
    end
    
else
        
     for j = 1:length(criticalPathBlock) 
         index1 = criticalPathBlock{j}(1);
         index2 = criticalPathBlock{j}(2);
         job1 = OS_offspring1(index1);   %工件1
         job2 = OS_offspring1(index2);   %工件2
            
         %%%交换工序码
         OS_offspring1(index1) = job2;
         OS_offspring1(index2) = job1;

         %%%交换机器码
         temp = MS_offspring1(sum(H(1:job1 - 1)) + s2(index1));
         MS_offspring1(sum(H(1:job1 - 1)) + s2(index1)) = MS_offspring1(sum(H(1:job2 - 1)) + s2(index2));
         MS_offspring1(sum(H(1:job2 - 1)) + s2(index2)) = temp;

         %%%交换机器速度码
         temp = SS_offspring1(sum(H(1:job1 - 1)) + s2(index1));
         SS_offspring1(sum(H(1:job1 - 1)) + s2(index1)) = SS_offspring1(sum(H(1:job2 - 1)) + s2(index2));
         SS_offspring1(sum(H(1:job2 - 1)) + s2(index2)) = temp;
            
     end
        
end


end