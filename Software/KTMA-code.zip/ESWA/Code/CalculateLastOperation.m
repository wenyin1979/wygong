function [value, machineWorkload, processingTime] = CalculateLastOperation(s1, s2, mm, ss, digraph, last, VELTime, processingTime, machineWorkload, machineBreakdownInterval, machineRepairTime)

Index = last;
e = 0;
t1 = e;
t2 = e;
if digraph(Index, 3) ~= 0
    zlast = digraph(Index, 3);
    if isempty(VELTime{zlast, 1})          
        [VELTime{zlast, 1}, machineWorkload, processingTime] = CalculateLastOperation(s1, s2, mm, ss, digraph, zlast, VELTime, processingTime, machineWorkload, machineBreakdownInterval, machineRepairTime);
    end
    if machineWorkload(ss(zlast)) + processingTime{s1(zlast)}(s2(zlast), mm(zlast)) / ss(zlast) >= machineBreakdownInterval(ss(zlast))
        processingTime{s1(zlast)}(s2(zlast), mm(zlast)) = processingTime{s1(zlast)}(s2(zlast), mm(zlast)) + machineRepairTime(mm(zlast)) * ss(zlast);
        t1 = processingTime{s1(zlast)}(s2(zlast), mm(zlast)) / ss(zlast) + VELTime{zlast, 1};
        machineWorkload(mm(zlast)) = machineWorkload(mm(zlast)) + processingTime{s1(zlast)}(s2(zlast), mm(zlast)) / ss(zlast) - machineBreakdownInterval(mm(zlast));      %机器修复完毕后重置机器负载
    else
        t1 = processingTime{s1(zlast)}(s2(zlast), mm(zlast)) / ss(zlast) + VELTime{zlast, 1};
        machineWorkload(mm(zlast)) = machineWorkload(mm(zlast)) + processingTime{s1(zlast)}(s2(zlast), mm(zlast)) / ss(zlast) - machineBreakdownInterval(mm(zlast));
    end
end

if digraph(Index, 4) ~= 0
    zlast = digraph(Index, 4);
    if isempty(VELTime{zlast, 1})  
        [VELTime{zlast, 1}, machineWorkload, processingTime] = CalculateLastOperation(s1, s2, mm, ss, digraph, zlast, VELTime, processingTime, machineWorkload, machineBreakdownInterval, machineRepairTime);
    end
    if machineWorkload(ss(zlast)) + processingTime{s1(zlast)}(s2(zlast), mm(zlast)) / ss(zlast) >= machineBreakdownInterval(ss(zlast))
        processingTime{s1(zlast)}(s2(zlast), mm(zlast)) = processingTime{s1(zlast)}(s2(zlast), mm(zlast)) + machineRepairTime(mm(zlast)) * ss(zlast);
        t2 = processingTime{s1(zlast)}(s2(zlast), mm(zlast)) / ss(zlast) + VELTime{zlast, 1};
        machineWorkload(mm(zlast)) = machineWorkload(mm(zlast)) + processingTime{s1(zlast)}(s2(zlast), mm(zlast)) / ss(zlast) - machineBreakdownInterval(mm(zlast));      %机器修复完毕后重置机器负载
    else
        t2 = processingTime{s1(zlast)}(s2(zlast), mm(zlast)) / ss(zlast) + VELTime{zlast, 1};
        machineWorkload(mm(zlast)) = machineWorkload(mm(zlast)) + processingTime{s1(zlast)}(s2(zlast), mm(zlast)) / ss(zlast) - machineBreakdownInterval(mm(zlast));
    end
end   

if t1 > t2      %如果t1大于t2则
    VELTime{Index, 1} = t1;
else
    VELTime{Index, 1} = t2;
end
value = VELTime{Index, 1};
    
end