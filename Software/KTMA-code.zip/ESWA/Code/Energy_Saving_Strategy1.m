function startEndTime = Energy_Saving_Strategy1(p_chrom, m_chrom, s_chrom, makespan, startEndTime)
%%%使用右移策略，在不增加最大完工时间的基础上减小总能量消耗

global N H SH;

%%%每一列分布表示：当前工件工序下一个工序的索引，当前工序所在机器的下一个工序索引，当前工序工件的上一个工序的索引，当前工序所在机器的上一个工序的索引
digraph = zeros(SH, 4);    %由于矩阵自身的行号本身就可以表示索引值，所以省略一列
dflag = zeros(SH, 4);  %用于标记该点是否找到

%%%先完成解码标记每个工序的工件和工序号
s1 = p_chrom;
s2 = zeros(1, SH);
p = zeros(1, N);
    
for i = 1:SH
    p(s1(i)) = p(s1(i)) + 1;    %记录过程是否加工完成，完成一次加一
    s2(i) = p(s1(i));     %记录加工过程中，工件的次数
end
    
for i = 1:SH
    t1 = s1(i);   %记录到当前是哪个工件
    t2 = s2(i);   %记录当前工件是加工到第几次
    mm(i) = m_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器选择，因为机器码的排列表示该工件第几次加工所选的机器，是一段表示一个工件
    ss(i) = s_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器速度选择
end

%%%构建有向图
for i = 1:SH
    to = s1(i);
    tm = mm(i);
    for j= i+1:SH
        %%%找当前工件工序的下一个工序
        if to == s1(j) && dflag(i, 1) == 0
            digraph(i, 1)=j;
            dflag(i, 1) = 1;    %下指针已经找到
            digraph(j, 3) = i;
            dflag(j, 3) = 1;    %上指针已经找到
        end
        %%%找当前机器工序的下一个工序
        if tm == mm(j) && dflag(i, 2) == 0
            digraph(i, 2) = j;
            dflag(i, 2) = 1;
            digraph(j, 4) = i;
            dflag(j, 4) = 1;
        end
        
        %%%全部都找完跳出当前循环，或者如果当前工序当前工件的是最后一个工序
        if (dflag(i, 1) == 1 || s2(i) == H(s1(i))) && dflag(i,2) == 1
            break;
        end
           
    end
end


for i = 1:SH
    if digraph(i, 1) == 0 && digraph(i, 2) == 0     %无后续工序，加工机器无后续工序
        %%%当前工序
        job = s1(i);
        op = s2(i);
        time = startEndTime{job}(op, 2) - startEndTime{job}(op, 1);

        startEndTime{job}(op, 1) = makespan - time;
        startEndTime{job}(op, 2) = makespan;

    elseif digraph(i, 1) == 0 && digraph(i, 2) ~= 0     %无后续工序，加工机器有后续工序
        %%%当前工序
        job = s1(i);
        op = s2(i);
        time = startEndTime{job}(op, 2) - startEndTime{job}(op, 1);
        
        %%%加工机器的后续工序
        machineNextJob = s1(digraph(i, 2));
        machineNextOp = s2(digraph(i, 2));

        startEndTime{job}(op, 1) = startEndTime{machineNextJob}(machineNextOp, 1) - time;
        startEndTime{job}(op, 2) = startEndTime{job}(op, 1) + time;

    elseif digraph(i, 1) ~= 0 && digraph(i, 2) == 0     %有后续工件，加工机器无后续工序
        %%%当前工序
        job = s1(i);
        op = s2(i);
        time = startEndTime{job}(op, 2) - startEndTime{job}(op, 1);

        %%%后续工序
        nextJob = s1(digraph(i, 1));
        nextOp = s2(digraph(i, 1));
    
        startEndTime{job}(op, 1) = startEndTime{nextJob}(nextOp, 1) - time;
        startEndTime{job}(op, 2) = startEndTime{job}(op, 1) + time;

    else        %有后续工件，加工机器有后续工序
        %%%当前工序
        job = s1(i);
        op = s2(i);
        time = startEndTime{job}(op, 2) - startEndTime{job}(op, 1);

        %%%后续工序
        nextJob = s1(digraph(i, 1));
        nextOp = s2(digraph(i, 1));

        %%%加工机器的后续工序
        machineNextJob = s1(digraph(i, 2));
        machineNextOp = s2(digraph(i, 2));

        startEndTime{job}(op, 1) = min(startEndTime{nextJob}(nextOp, 1), startEndTime{machineNextJob}(machineNextOp, 1)) - time;
        startEndTime{job}(op, 2) = startEndTime{job}(op, 1) + time;

end


end