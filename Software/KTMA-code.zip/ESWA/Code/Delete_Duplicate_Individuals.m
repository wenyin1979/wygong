function [OS, MS, SS, objectiveValue, startEndTime] = Delete_Duplicate_Individuals(OS, MS, SS, objectiveValue, startEndTime)

global P;

len = size(OS, 1);
deleteIndex = [];
for i = 1:(len - 1)
    for j = (i + 1):len
        if ismember(i, deleteIndex)
            break;
        end
        
        if isequal(OS(i, :), OS(j, :)) && isequal(MS(i, :), MS(j, :)) && isequal(SS(i, :), SS(j, :))
            deleteIndex = [deleteIndex, j];
        end
    end
end

OS(deleteIndex, :) = [];
MS(deleteIndex, :) = [];
SS(deleteIndex, :) = [];
objectiveValue(deleteIndex, :) = [];
startEndTime(deleteIndex) = [];

end